jQuery(document).ready(function($){
// Add your custom jQuery here
});