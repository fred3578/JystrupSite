StanleyWP - Bootstrap 4 WordPress Theme
===

This theme was built in the tutorial series on how to create a Bootstrap 4 WordPress theme. 
