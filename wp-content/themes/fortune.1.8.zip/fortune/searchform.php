 <form action="<?php echo esc_url(home_url('/')); ?>" method="get" role="search">
  <div class="input-group">
	<input type="search" name="s" id="s" class="form-control" placeholder="<?php esc_attr_e('Search here...','fortune'); ?>">
	<span class="input-group-btn">
	<button class="btn btn-primary" type="button"><i class="fa fa-search"></i></button>
	</span> </div>
</form>
